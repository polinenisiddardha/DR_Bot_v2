import requests
import re

class Authenticate:

    def authenticate(self,username,password,url):





        username = username

        password = password

        URL = '{}/v1/authentication'.format(url)

        data = {'username':username,'password':password}

        r = requests.post(url = URL, json = data)

        token = r.text
        print(token)

        pattren= re.compile('{"token":"([A-Za-z0-9\W\_*]+)","user":')
        Extrctd_Token= pattren.search(token)
        FinalToken=Extrctd_Token.group(1)
        # print('Final Token is  ' + FinalToken)
        return FinalToken
