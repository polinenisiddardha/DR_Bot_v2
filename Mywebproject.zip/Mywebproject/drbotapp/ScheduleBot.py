import requests
import re

class ScheduleBot:
    def schedulebot(self,FinalToken,File_Id,Device_Id,filename,startdate,enddate,starttime,description,rdp,type,repeat,status,timeZone):

        # filename = "external.config"
        #
        # contents = open(filename).read()
        #
        # config = eval(contents)

        atmxfile = filename

        startdate = startdate

        enddate = enddate

        time = starttime

        Description1 = description

        rdp = rdp

        type = type

        repeat = repeat

        status1 = status

        zone = timeZone

        headers = {'content-type': 'application/json' ,'X-Authorization': FinalToken}

        payload = {"name": atmxfile, "fileId": File_Id, "startDate": startdate, "endDate": enddate,  "startTime": time, "description": Description1, "rdpEnabled": rdp, "scheduleType": type, "repeatEnabled": repeat,  "status": status1, "timeZone": zone, "deviceIds":[ Device_Id]}

        r = requests.post(url='http://laptop-cuh100vd/v1/schedule/automations', headers=headers, json=payload, verify=False)

        schedule = r.text
        print(schedule)

        pattren= re.compile('"id": "([0-9]+)"')
        Extrctd_id= pattren.search(schedule)
        schedule_Id=Extrctd_id.group(1)
        print('ScheduleId is  ' + schedule_Id)


        print(r.text)
        return schedule_Id