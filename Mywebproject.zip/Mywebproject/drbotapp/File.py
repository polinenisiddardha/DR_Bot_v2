import requests
import re

class File:
    def fileID(self,FinalToken,filename,url):


        print('.........i am in fileid...........')
        atmxfile = filename


        headers = {'content-type': 'application/json' ,'X-Authorization': FinalToken}

        payload = {'filter':{'operator':'eq', 'value':atmxfile, 'field':'fileName'}}

        r = requests.post(url='{}/v2/repository/file/list'.format(url), headers=headers, json=payload, verify=False)

        file = r.text
        print(file)

        pattren= re.compile('"id":"([0-9]+)"')
        Extrctd_id= pattren.search(file)
        File_Id=Extrctd_id.group(1)
        print('File ID is  ' +File_Id)


        print(r.text)
        return File_Id