from rest_framework.generics import ListAPIView
from rest_framework import viewsets
from .serializers import Employeeserializer
from .models import Employee
from rest_framework.permissions import IsAuthenticated




class Employeeviewset(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,) 
    queryset = Employee.objects.all()
    serializer_class = Employeeserializer

# class rpadeviceviewset(viewsets.ModelViewSet):
