import requests
class Deploy:
    def deploybot(self,FinalToken,File_Id,Device_Id,url):

        headers = {'content-type': 'application/json' ,'X-Authorization': FinalToken}

        payload = {"fileId": File_Id, "deviceIds": [Device_Id]}

        r = requests.post(url='{}/v2/automations/deploy'.format(url), headers=headers, json=payload, verify=False)

        print(r.text)