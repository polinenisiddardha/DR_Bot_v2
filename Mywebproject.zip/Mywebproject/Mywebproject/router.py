from drbotapp.api_view import Employeeviewset
from rest_framework import routers

router = routers.DefaultRouter()
router.register('employee',Employeeviewset)